package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

//    private DatabaseReference minhaReferencia = FirebaseDatabase.getInstance().getReference();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        minhaReferencia.child("produtos").child("001").child("nome").child("Coca-Cola");
//        minhaReferencia.child("produtos").child("001").child("preço").child("3.50");

        DatabaseReference produtos = minhaReferencia.child("produtos");

        Produtos p = new Produtos();
        p.setNome("Pepsi");
        p.setPreco(3.50);

        produtos.child("001").setValue(p);

    }

}