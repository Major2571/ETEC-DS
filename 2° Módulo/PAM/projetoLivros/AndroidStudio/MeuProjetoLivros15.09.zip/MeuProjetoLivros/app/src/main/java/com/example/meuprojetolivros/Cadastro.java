package com.example.meuprojetolivros;

import android.app.Activity;
import android.os.Bundle;

public class Cadastro extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_cadastro);
    }
}
